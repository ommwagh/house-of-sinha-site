House of Sinha — Diwali Night 2025 (v5 with header fixes)

Changes in this build:
- **Logo added** to the left corner using your provided image.
- **Nav links aligned** in a straight line with proper vertical centering.
- Neon red + black theme preserved.

Preview locally:
1) Unzip
2) Double-click index.html

Deploy to Vercel:
1) Upload these files to a GitHub repo (index.html at the repo root, plus the assets folder)
2) Vercel → New Project → Import from GitHub → Framework "Other" → Output "." → Deploy
3) Add your domain in Settings → Domains

Tip: It's best to make these visual tweaks **before** the first deploy so you don't redeploy twice. But if you've already deployed, just push this updated index.html and Vercel will auto‑update.
