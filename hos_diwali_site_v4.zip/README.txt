House of Sinha — Diwali Night 2025 (Neon Red/Black v4)
=========================================================

Files
-----
- index.html
- assets/favicon.png
- assets/og-image.png
- assets/logo-hos.png
- assets/poster1.pdf (if provided)
- assets/poster2.pdf (if provided)
- assets/poster1-thumb.png
- assets/poster2-thumb.png

Preview locally
---------------
1) Unzip the folder
2) Double-click index.html to open in your browser

Deploy (Vercel)
---------------
1) Upload files to a GitHub repo (index.html at the root + assets folder)
2) Vercel → New Project → Import GitHub → Framework: 'Other' → Output: '.'
3) Deploy and add your custom domain houseofsinha.com in Settings → Domains

Editing
-------
- For text tweaks, edit index.html in GitHub directly (browser → Edit → Commit).
- Replace poster PDFs by uploading new files into assets/ with the same names.
- Wire ticket buttons: search for 'Buy Now' and replace href="#" with Stripe/Wix/Eventbrite links.
